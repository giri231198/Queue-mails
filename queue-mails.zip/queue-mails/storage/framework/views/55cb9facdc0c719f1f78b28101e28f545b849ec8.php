<!DOCTYPE html>
<html>
<head>
    <title>Send Email using Queue</title>
</head>
<body>
    <p><?php echo e($details['body']); ?></p>
  
    <p>Thank you</p>
</body>
</html><?php /**PATH D:\xampp\htdocs\queue-mails\resources\views/emails/notification.blade.php ENDPATH**/ ?>