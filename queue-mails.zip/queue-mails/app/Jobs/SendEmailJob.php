<?php

namespace App\Jobs;

use App\Mail\NotificationEmail;
use Illuminate\Bus\Queueable;
use Illuminate\Support\Facades\Mail;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Exception;


class SendEmailJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    protected $details;

    public function __construct($details)
    {
        $this->details = $details;
    }

    public function handle()
    {
        Mail::to($this->details['to'])->send(new NotificationEmail($this->details));
    }
    public $tries = 5;  

    public $backoff = 30;  

    public function failed(Exception $exception)
    {
        // Handle the failure (e.g., log the error, notify admins, etc.)
        \Log::error('Email failed to send: '.$exception->getMessage());
    }
}
