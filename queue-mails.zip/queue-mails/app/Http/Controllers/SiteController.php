<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;
use App\Mail\SentMailDemo;
use App\Jobs\SendEmailJob;
use DB;

class SiteController extends Controller
{
    /**
     * Display a listing of the resource.
     */

     public function index(Request $request)
    {
        $failed_jobs = DB::table( 'failed_jobs' )->get();

        // dd($failed_jobs);

        return view( 'welcome', compact('failed_jobs') );
    }
    public function sendmail(Request $request)
    {
        $details = [
            'to' => $request->email,
            'subject' => $request->subject,
            'body' => $request->message
        ];

        // dd($emaildata);
        if (isset($details['to']) && isset($details['subject']) && isset($details['body'])) {
            SendEmailJob::dispatch($details);
        } else {
            \Log::error('SendNotification: Data is incomplete or invalid.');
        } 
       
        notify()->success('Email Sented Successfully');
        return redirect()->back();
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        
    }
}
