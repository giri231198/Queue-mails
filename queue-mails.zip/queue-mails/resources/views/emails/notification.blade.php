<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <p>{{ $details['body'] }}</p>
  
    <p>Thank you</p>
</body>
</html>